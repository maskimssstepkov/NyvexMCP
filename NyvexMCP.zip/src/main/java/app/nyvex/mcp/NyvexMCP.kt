package app.nyvex.mcp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.widget.Button
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.WindowManager
import android.content.res.Configuration
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import android.widget.ScrollView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.security.SecureRandom
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

const val PORT = 8765

fun Context.nyvexPrefs(): SharedPreferences = getSharedPreferences("nyvex", Context.MODE_PRIVATE)

fun Context.nyvexToken(): String =
    nyvexPrefs().getString("token", null) ?: newToken(nyvexPrefs())

fun newToken(p: SharedPreferences): String {
    val b = ByteArray(24)
    SecureRandom().nextBytes(b)
    val t = Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    p.edit().putString("token", t).apply()
    return t
}

// ───────────────────────── Accessibility: руки и глаза ─────────────────────────
class NyvexAccessibility : AccessibilityService() {
    companion object {
        @Volatile var instance: NyvexAccessibility? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun gesture(path: Path, dur: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur.coerceAtLeast(1))).build()
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(10, TimeUnit.SECONDS)
        return ok
    }

    fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 50)
    fun longPress(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 800)
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) =
        gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, ms)

    fun key(name: String): Boolean {
        val a = when (name.uppercase()) {
            "BACK" -> GLOBAL_ACTION_BACK
            "HOME" -> GLOBAL_ACTION_HOME
            "RECENTS", "APP_SWITCH" -> GLOBAL_ACTION_RECENTS
            "NOTIFICATIONS" -> GLOBAL_ACTION_NOTIFICATIONS
            "QUICK_SETTINGS" -> GLOBAL_ACTION_QUICK_SETTINGS
            "LOCK" -> GLOBAL_ACTION_LOCK_SCREEN
            "POWER" -> GLOBAL_ACTION_POWER_DIALOG
            else -> return false
        }
        return performGlobalAction(a)
    }

    fun typeText(text: String, replace: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val old = if (replace) "" else node.text?.toString().orEmpty()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findEditable(c)?.let { return it } }
        return null
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var n: AccessibilityNodeInfo = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return false
        val r = Rect(); n.getBoundsInScreen(r)
        while (!n.isClickable) n = n.parent ?: return tap(r.centerX().toFloat(), r.centerY().toFloat())
        return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun uiTree(): String {
        val root = rootInActiveWindow ?: return "нет активного окна"
        val sb = StringBuilder()
        dump(root, sb, 0)
        return sb.toString()
    }

    private fun dump(n: AccessibilityNodeInfo, sb: StringBuilder, d: Int) {
        val r = Rect(); n.getBoundsInScreen(r)
        val t = n.text?.toString().orEmpty()
        val c = n.contentDescription?.toString().orEmpty()
        if (t.isNotEmpty() || c.isNotEmpty() || n.isClickable || n.isEditable) {
            sb.append(" ".repeat(minOf(d, 10)))
                .append(n.className?.toString()?.substringAfterLast('.'))
                .append(" @").append(r.centerX()).append(',').append(r.centerY())
            if (t.isNotEmpty()) sb.append(" text=\"").append(t.take(120)).append('"')
            if (c.isNotEmpty()) sb.append(" desc=\"").append(c.take(120)).append('"')
            n.viewIdResourceName?.let { sb.append(" id=").append(it.substringAfter(":id/")) }
            if (n.isClickable) sb.append(" [click]")
            if (n.isEditable) sb.append(" [edit]")
            sb.append('\n')
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { dump(it, sb, d + 1) }
    }

    /** JPEG в base64 или null (нужен Android 11+). */
    fun screenshot(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: String? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bmp != null) {
                    val s = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 55, s)
                    out = Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP)
                }
                latch.countDown()
            }
            override fun onFailure(code: Int) { latch.countDown() }
        })
        latch.await(10, TimeUnit.SECONDS)
        return out
    }

    fun screenSize(): String {
        val m = resources.displayMetrics
        return "${m.widthPixels}x${m.heightPixels}"
    }
}

// ───────────────────────── MCP-сервер (Streamable HTTP, JSON-RPC) ─────────────────────────
class McpServer(private val ctx: Context, private val token: () -> String) :
    NanoHTTPD("127.0.0.1", PORT) {

    private fun txt(s: String) = JSONObject().put("content", JSONArray().put(JSONObject().put("type", "text").put("text", s)))
    private fun err(s: String) = txt(s).put("isError", true)

    private fun tool(name: String, desc: String, props: List<Pair<String, String>> = emptyList(), req: List<String> = props.map { it.first }): JSONObject {
        val p = JSONObject()
        props.forEach { p.put(it.first, JSONObject().put("type", it.second)) }
        return JSONObject().put("name", name).put("description", desc).put(
            "inputSchema", JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(req))
        )
    }

    fun tools() = JSONArray()
        .put(tool("screenshot", "Скриншот экрана (JPEG)"))
        .put(tool("ui_tree", "Дерево элементов экрана: текст, центр @x,y, [click]/[edit]. Точнее скриншота для кликов"))
        .put(tool("screen_size", "Разрешение экрана в пикселях"))
        .put(tool("tap", "Тап по координатам", listOf("x" to "number", "y" to "number")))
        .put(tool("long_press", "Долгое нажатие", listOf("x" to "number", "y" to "number")))
        .put(tool("swipe", "Свайп/скролл", listOf("x1" to "number", "y1" to "number", "x2" to "number", "y2" to "number", "duration_ms" to "number"), listOf("x1", "y1", "x2", "y2")))
        .put(tool("type_text", "Ввод текста в активное поле (любые языки). replace=true заменяет текст", listOf("text" to "string", "replace" to "boolean"), listOf("text")))
        .put(tool("click_text", "Нажать элемент по тексту", listOf("text" to "string")))
        .put(tool("key", "BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK, POWER", listOf("name" to "string")))
        .put(tool("list_apps", "Установленные приложения: название | пакет"))
        .put(tool("open_app", "Запустить приложение по пакету", listOf("package" to "string")))
        .put(tool("open_url", "Открыть ссылку", listOf("url" to "string")))
        .put(tool("wait", "Пауза в мс (макс 10000)", listOf("ms" to "number")))

    fun call(name: String, a: JSONObject): JSONObject {
        val svc = NyvexAccessibility.instance
        val c: Context = svc ?: ctx
        try {
            when (name) {
                "list_apps" -> {
                    val pm = c.packageManager
                    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    return txt(pm.queryIntentActivities(i, 0).joinToString("\n") { "${it.loadLabel(pm)} | ${it.activityInfo.packageName}" })
                }
                "open_app" -> {
                    val i = c.packageManager.getLaunchIntentForPackage(a.getString("package")) ?: return err("пакет не найден")
                    c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return txt("ok")
                }
                "open_url" -> {
                    c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return txt("ok")
                }
                "wait" -> { Thread.sleep(a.optLong("ms", 1000).coerceIn(0, 10000)); return txt("ok") }
            }
            if (svc == null) return err("Спец. возможности NyvexMCP выключены. Включи их в настройках телефона.")
            fun f(k: String) = a.getDouble(k).toFloat()
            return when (name) {
                "screenshot" -> {
                    val b64 = svc.screenshot() ?: return err("скриншот недоступен (нужен Android 11+)")
                    JSONObject().put("content", JSONArray().put(JSONObject().put("type", "image").put("data", b64).put("mimeType", "image/jpeg")))
                }
                "ui_tree" -> txt(svc.uiTree())
                "screen_size" -> txt(svc.screenSize())
                "tap" -> txt(if (svc.tap(f("x"), f("y"))) "ok" else "fail")
                "long_press" -> txt(if (svc.longPress(f("x"), f("y"))) "ok" else "fail")
                "swipe" -> txt(if (svc.swipe(f("x1"), f("y1"), f("x2"), f("y2"), a.optLong("duration_ms", 300))) "ok" else "fail")
                "type_text" -> txt(if (svc.typeText(a.getString("text"), a.optBoolean("replace", false))) "ok" else "нет поля ввода в фокусе")
                "click_text" -> txt(if (svc.clickText(a.getString("text"))) "ok" else "не найдено")
                "key" -> txt(if (svc.key(a.getString("name"))) "ok" else "fail")
                else -> err("неизвестный инструмент")
            }
        } catch (e: Exception) {
            return err(e.message ?: e.toString())
        }
    }

    private fun plain(s: Status, t: String) = newFixedLengthResponse(s, "text/plain", t)

    override fun serve(s: IHTTPSession): Response {
        val tok = token()
        val viaPath = MessageDigest.isEqual(s.uri.toByteArray(), "/mcp/$tok".toByteArray())
        val viaHeader = s.uri == "/mcp" &&
            MessageDigest.isEqual((s.headers["authorization"] ?: "").toByteArray(), "Bearer $tok".toByteArray())
        if (!viaPath && !viaHeader) return plain(Status.UNAUTHORIZED, "unauthorized")
        if (s.method == Method.DELETE) return plain(Status.OK, "")
        if (s.method != Method.POST) return plain(Status.METHOD_NOT_ALLOWED, "")
        return try {
            val files = HashMap<String, String>()
            s.parseBody(files)
            val req = JSONObject(files["postData"] ?: "{}")
            val id = req.opt("id") ?: return plain(Status.ACCEPTED, "")
            val params = req.optJSONObject("params") ?: JSONObject()
            val res = JSONObject().put("jsonrpc", "2.0").put("id", id)
            when (req.optString("method")) {
                "initialize" -> res.put("result", JSONObject()
                    .put("protocolVersion", params.optString("protocolVersion", "2025-03-26"))
                    .put("capabilities", JSONObject().put("tools", JSONObject()))
                    .put("serverInfo", JSONObject().put("name", "NyvexMCP").put("version", "1.8")))
                "ping" -> res.put("result", JSONObject())
                "tools/list" -> res.put("result", JSONObject().put("tools", tools()))
                "tools/call" -> res.put("result", call(params.optString("name"), params.optJSONObject("arguments") ?: JSONObject()))
                else -> res.put("error", JSONObject().put("code", -32601).put("message", "method not found"))
            }
            newFixedLengthResponse(Status.OK, "application/json", res.toString())
        } catch (e: Exception) {
            plain(Status.BAD_REQUEST, e.message ?: "bad request")
        }
    }
}

// ───────────────────────── Фоновая служба (вкл/выкл) ─────────────────────────
class McpService : Service() {
    companion object {
        @Volatile var running = false
        const val STOP = "app.nyvex.mcp.STOP"
    }

    private var server: McpServer? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?) = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("mcp", "NyvexMCP", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, McpService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "mcp")
            .setContentTitle("NyvexMCP включён")
            .setContentText("127.0.0.1:$PORT")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (server == null) {
            server = McpServer(this) { nyvexToken() }.also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
            wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nyvex:mcp").apply { acquire() }
        }
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop(); server = null
        wl?.let { if (it.isHeld) it.release() }
        running = false
        super.onDestroy()
    }
}

// ───────────────────────── Агент: голос → Claude API → действия на телефоне ─────────────────────────
object Agent {
    private const val SYSTEM =
        "Ты Клод, голосовой ассистент на телефоне пользователя. Управляй телефоном инструментами: " +
        "сначала ui_tree (или screenshot), потом действия, после действий проверяй результат. " +
        "Отвечай по-русски, коротко (1-2 предложения), без markdown и списков: ответ озвучивается. " +
        "Перед необратимыми действиями (платежи, удаление, отправка сообщений другим людям) сначала задай вопрос " +
        "и дождись подтверждения."

    private class Cfg(val base: String, val key: String, val model: String, val openai: Boolean)

    private var history = JSONArray()
    private var last = 0L
    private var sysPrompt = ""
    private var lastOpenai = false

    private fun cfg(ctx: Context): Cfg {
        val p = ctx.nyvexPrefs()
        return Cfg(
            p.getString("base_url", "").orEmpty().ifBlank { "https://darkapi.shop/v1" },
            p.getString("api_key", "").orEmpty(),
            p.getString("model", "").orEmpty().ifBlank { "claude-sonnet-5-5" },
            p.getBoolean("openai", false)
        )
    }

    private fun endpoint(c: Cfg): String {
        val b = c.base.trim().trimEnd('/')
        if (b.contains("/chat/completions") || b.endsWith("/messages")) return b
        val v1 = if (b.endsWith("/v1")) b else "$b/v1"
        return v1 + if (c.openai) "/chat/completions" else "/messages"
    }

    fun run(ctx: Context, userText: String): String {
        val c = cfg(ctx)
        sysPrompt = SYSTEM.replace("Ты Клод", "Ты " + ctx.nyvexPrefs().getString("name", "").orEmpty().ifBlank { "Клод" })
        if (c.key.isBlank()) return "Нет API-ключа. Введи его в приложении."
        if (System.currentTimeMillis() - last > 120_000 || c.openai != lastOpenai) history = JSONArray()
        lastOpenai = c.openai
        val srv = McpServer(ctx) { "" }
        val defs = srv.tools()
        return if (c.openai) runOpenAI(c, srv, defs, userText) else runAnthropic(c, srv, defs, userText)
    }

    // ── формат Anthropic (/v1/messages) ──
    private fun runAnthropic(c: Cfg, srv: McpServer, defs: JSONArray, userText: String): String {
        val tools = JSONArray()
        for (i in 0 until defs.length()) {
            val t = defs.getJSONObject(i)
            tools.put(JSONObject().put("name", t.getString("name")).put("description", t.getString("description"))
                .put("input_schema", t.getJSONObject("inputSchema")))
        }
        history.put(JSONObject().put("role", "user").put("content", userText))
        for (step in 0 until 25) {
            pruneImages()
            val body = JSONObject().put("model", c.model).put("max_tokens", 1024).put("system", sysPrompt)
                .put("tools", tools).put("messages", history).toString()
            val resp = http(endpoint(c), mapOf("x-api-key" to c.key, "Authorization" to "Bearer ${c.key}", "anthropic-version" to "2023-06-01"), body)
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            last = System.currentTimeMillis()
            if (resp.optString("stop_reason") != "tool_use") {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().ifBlank { "Готово" }
            }
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") != "tool_use") continue
                val r = srv.call(b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                val out = JSONArray()
                val rc = r.getJSONArray("content")
                for (j in 0 until rc.length()) {
                    val x = rc.getJSONObject(j)
                    if (x.getString("type") == "image") out.put(JSONObject().put("type", "image").put("source",
                        JSONObject().put("type", "base64").put("media_type", x.getString("mimeType")).put("data", x.getString("data"))))
                    else out.put(JSONObject().put("type", "text").put("text", x.getString("text")))
                }
                results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id"))
                    .put("content", out).put("is_error", r.optBoolean("isError", false)))
            }
            history.put(JSONObject().put("role", "user").put("content", results))
        }
        return "Не успел закончить, слишком много шагов."
    }

    // ── формат OpenAI (/v1/chat/completions) ──
    private fun runOpenAI(c: Cfg, srv: McpServer, defs: JSONArray, userText: String): String {
        val tools = JSONArray()
        for (i in 0 until defs.length()) {
            val t = defs.getJSONObject(i)
            tools.put(JSONObject().put("type", "function").put("function", JSONObject()
                .put("name", t.getString("name")).put("description", t.getString("description"))
                .put("parameters", t.getJSONObject("inputSchema"))))
        }
        history.put(JSONObject().put("role", "user").put("content", userText))
        for (step in 0 until 25) {
            pruneImagesOA()
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sysPrompt))
            for (i in 0 until history.length()) msgs.put(history.get(i))
            val body = JSONObject().put("model", c.model).put("max_tokens", 1024)
                .put("messages", msgs).put("tools", tools).toString()
            val resp = http(endpoint(c), mapOf("Authorization" to "Bearer ${c.key}"), body)
            val msg = resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
            history.put(msg)
            last = System.currentTimeMillis()
            val calls = msg.optJSONArray("tool_calls")
            if (calls == null || calls.length() == 0) {
                val t = msg.optString("content")
                return if (t.isBlank() || t == "null") "Готово" else t
            }
            val imgs = ArrayList<String>()
            for (i in 0 until calls.length()) {
                val call = calls.getJSONObject(i)
                val fn = call.getJSONObject("function")
                val args = try { JSONObject(fn.optString("arguments", "{}").ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
                val r = srv.call(fn.getString("name"), args)
                val rc = r.getJSONArray("content")
                val sb = StringBuilder()
                for (j in 0 until rc.length()) {
                    val x = rc.getJSONObject(j)
                    if (x.getString("type") == "image") imgs.add(x.getString("data")) else sb.append(x.getString("text"))
                }
                if (sb.isEmpty()) sb.append("скриншот в следующем сообщении")
                history.put(JSONObject().put("role", "tool").put("tool_call_id", call.getString("id")).put("content", sb.toString()))
            }
            if (imgs.isNotEmpty()) {
                val parts = JSONArray().put(JSONObject().put("type", "text").put("text", "Скриншот экрана"))
                imgs.forEach { parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$it"))) }
                history.put(JSONObject().put("role", "user").put("content", parts))
            }
        }
        return "Не успел закончить, слишком много шагов."
    }

    private fun pruneImagesOA() {
        for (m in 0 until history.length() - 1) {
            val c = history.getJSONObject(m).opt("content") as? JSONArray ?: continue
            for (i in 0 until c.length()) {
                if (c.getJSONObject(i).optString("type") == "image_url")
                    c.put(i, JSONObject().put("type", "text").put("text", "[старый скриншот]"))
            }
        }
    }

    /** Старые скриншоты заменяем текстом, чтобы не раздувать контекст. */
    private fun pruneImages() {
        for (m in 0 until history.length() - 1) {
            val c = history.getJSONObject(m).opt("content") as? JSONArray ?: continue
            for (i in 0 until c.length()) {
                val b = c.getJSONObject(i)
                if (b.optString("type") != "tool_result") continue
                val inner = b.optJSONArray("content") ?: continue
                for (j in 0 until inner.length()) {
                    if (inner.getJSONObject(j).optString("type") == "image")
                        inner.put(j, JSONObject().put("type", "text").put("text", "[старый скриншот]"))
                }
            }
        }
    }

    private fun http(url: String, headers: Map<String, String>, body: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 90000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val st = if (code in 200..299) c.inputStream else c.errorStream
        val txt = st?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw RuntimeException("API $code: ${txt.take(200)}")
        return JSONObject(txt)
    }
}

// ───────────────────────── Голосовая служба ─────────────────────────
class VoiceService : Service() {
    companion object {
        @Volatile var running = false
        const val STOP = "app.nyvex.mcp.VSTOP"
    }

    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wl: PowerManager.WakeLock? = null
    private var busy = false
    private var awaiting = false
    private var overlay: TextView? = null
    private val hideOverlay = Runnable { removeOverlay() }

    private fun name() = nyvexPrefs().getString("name", "").orEmpty().ifBlank { "Клод" }

    private fun wakeRegex(): Regex {
        val alts = mutableListOf(Regex.escape(name().lowercase()))
        if (name() == "Клод") alts += listOf("клауд", "клот", "claude")
        return Regex(alts.joinToString("|"), RegexOption.IGNORE_CASE)
    }

    override fun onBind(i: Intent?) = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("voice", "Голосовой помощник", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, VoiceService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "voice")
            .setContentTitle("Слушаю: скажи «${name()}»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(2, n)
        if (!running) {
            running = true
            wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nyvex:voice").apply { acquire() }
            tts = TextToSpeech(this) { st ->
                val e = tts
                if (st == TextToSpeech.SUCCESS && e != null) {
                    e.language = Locale("ru", "RU")
                    e.setSpeechRate(1.05f)
                    e.setPitch(1.05f)
                    e.voices?.filter { it.locale.language == "ru" }?.maxByOrNull { it.quality }?.let { e.voice = it }
                    e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { main.post { busy = false; listen() } }
                        @Deprecated("deprecated") override fun onError(id: String?) { main.post { busy = false; listen() } }
                    })
                }
            }
            main.post {
                sr = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
                listen()
            }
        }
        return START_STICKY
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onError(e: Int) { main.postDelayed({ listen() }, 400) }
        override fun onResults(r: Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            handle(t)
        }
    }

    private fun listen() {
        if (!running || busy) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        try { sr?.startListening(i) } catch (e: Exception) { main.postDelayed({ listen() }, 1000) }
    }

    private fun handle(text: String) {
        val m = wakeRegex().find(text)
        val cmd = when {
            m != null -> text.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?')
            awaiting -> text.trim()
            else -> { listen(); return }
        }
        if (m != null) showOverlay("🎙 ${name()} слушает")
        if (cmd.isBlank()) { awaiting = true; say("Слушаю"); return }
        awaiting = false
        busy = true
        showOverlay("… ${name()} думает")
        Thread {
            val reply = try { Agent.run(this, cmd) } catch (e: Exception) { "Ошибка: ${e.message}" }
            awaiting = reply.trimEnd().endsWith("?")
            main.post { say(reply) }
        }.start()
    }

    private fun say(t: String) {
        showOverlay(t)
        val engine = tts
        if (!nyvexPrefs().getBoolean("speak", true) || engine == null) {
            busy = false
            main.postDelayed({ listen() }, 300)
            return
        }
        busy = true
        engine.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun createOverlay(wm: WindowManager): TextView {
        val tv = TextView(this).apply {
            setPadding(48, 28, 48, 28)
            textSize = 17f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(0xEE202124.toInt()); cornerRadius = 48f }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 180 }
        wm.addView(tv, lp)
        return tv
    }

    private fun showOverlay(t: String) {
        main.post {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
                return@post
            }
            val view = overlay ?: createOverlay(getSystemService(WindowManager::class.java)).also { overlay = it }
            view.text = t
            main.removeCallbacks(hideOverlay)
            main.postDelayed(hideOverlay, 5000)
        }
    }

    private fun removeOverlay() {
        overlay?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        overlay = null
    }

    override fun onDestroy() {
        running = false
        removeOverlay()
        sr?.destroy(); sr = null
        tts?.shutdown(); tts = null
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}

// ───────────────────────── Экран приложения ─────────────────────────
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var info: TextView
    private lateinit var swVoice: Switch
    private lateinit var swMcp: Switch
    private lateinit var swSpeak: Switch
    private lateinit var swOpenAI: Switch
    private lateinit var nameField: EditText
    private lateinit var urlField: EditText
    private lateinit var modelField: EditText
    private lateinit var keyField: EditText
    private lateinit var rg: RadioGroup
    private var updating = false
    private val h = Handler(Looper.getMainLooper())
    private val themes = listOf("system" to "Системная", "light" to "Светлая", "dark" to "Тёмная")

    private fun isDark(): Boolean = when (nyvexPrefs().getString("theme", "system")) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun name() = nyvexPrefs().getString("name", "").orEmpty().ifBlank { "Клод" }

    override fun onCreate(b: Bundle?) {
        setTheme(if (isDark()) android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar)
        super.onCreate(b)
        val perms = mutableListOf("android.permission.RECORD_AUDIO")
        if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
        requestPermissions(perms.toTypedArray(), 1)

        val prefs = nyvexPrefs()
        val pad = (16 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply { text = "NyvexMCP"; textSize = 28f })
        root.addView(TextView(this).apply { text = "Версия " + packageManager.getPackageInfo(packageName, 0).versionName; textSize = 14f })

        swVoice = Switch(this).apply { textSize = 18f; setPadding(0, pad / 2, 0, pad / 2) }
        swVoice.setOnCheckedChangeListener { _, on -> toggle(VoiceService::class.java, on) }
        swMcp = Switch(this).apply { text = "MCP-сервер (для внешнего Claude)"; textSize = 16f; setPadding(0, pad / 2, 0, pad / 2) }
        swMcp.setOnCheckedChangeListener { _, on -> toggle(McpService::class.java, on) }
        root.addView(swVoice)
        root.addView(swMcp)
        info = TextView(this).apply { textSize = 14f; setTextIsSelectable(true); setPadding(0, pad / 2, 0, pad) }
        root.addView(info)

        root.addView(TextView(this).apply { text = "Настройки"; textSize = 20f })
        nameField = field("Имя ассистента (пусто = Клод)", prefs.getString("name", "").orEmpty(), InputType.TYPE_CLASS_TEXT)
        swSpeak = Switch(this).apply { text = "Отвечать голосом"; isChecked = prefs.getBoolean("speak", true) }
        root.addView(nameField)
        root.addView(swSpeak)

        root.addView(TextView(this).apply { text = "Тема" })
        rg = RadioGroup(this)
        themes.forEachIndexed { i, p -> rg.addView(RadioButton(this).apply { id = 100 + i; text = p.second }) }
        rg.check(100 + themes.indexOfFirst { it.first == prefs.getString("theme", "system") }.coerceAtLeast(0))
        root.addView(rg)

        val tokenType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        urlField = field("Base URL (пусто = https://darkapi.shop/v1)", prefs.getString("base_url", "").orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        modelField = field("Модель (пусто = claude-sonnet-5-5)", prefs.getString("model", "").orEmpty(), InputType.TYPE_CLASS_TEXT)
        keyField = field("API-ключ", "", tokenType)
        swOpenAI = Switch(this).apply { text = "Формат OpenAI (chat/completions)"; isChecked = prefs.getBoolean("openai", false) }
        root.addView(urlField)
        root.addView(modelField)
        root.addView(keyField)
        root.addView(swOpenAI)

        fun btn(t: String, a: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        btn("Сохранить настройки") { save() }
        btn("Разрешить всплывающие окна") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Включить спец. возможности") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("Отключить оптимизацию батареи") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        btn("Копировать MCP-URL (подставь свой туннель)") {
            val url = "https://ТВОЙ-ТУННЕЛЬ/mcp/${nyvexToken()}"
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("mcp", url))
        }
        btn("Сменить MCP-токен") { newToken(nyvexPrefs()); refresh() }

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun field(hintText: String, v: String, type: Int) = EditText(this).apply {
        hint = hintText
        setText(v)
        inputType = type
    }

    private fun toggle(cls: Class<*>, on: Boolean) {
        if (updating) return
        val i = Intent(this, cls)
        if (on) startForegroundService(i) else stopService(i)
        h.postDelayed({ refresh() }, 700)
    }

    private fun save() {
        val prefs = nyvexPrefs()
        val prevTheme = prefs.getString("theme", "system")
        val newTheme = themes.getOrNull(rg.checkedRadioButtonId - 100)?.first ?: prevTheme
        val e = prefs.edit()
            .putString("name", nameField.text.toString().trim())
            .putBoolean("speak", swSpeak.isChecked)
            .putString("theme", newTheme)
            .putString("base_url", urlField.text.toString().trim())
            .putString("model", modelField.text.toString().trim())
            .putBoolean("openai", swOpenAI.isChecked)
        val k = keyField.text.toString().trim()
        if (k.isNotEmpty()) e.putString("api_key", k)
        e.apply()
        keyField.setText("")
        if (newTheme != prevTheme) recreate() else refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        updating = true
        swVoice.isChecked = VoiceService.running
        swMcp.isChecked = McpService.running
        updating = false
        swVoice.text = "Голос: скажи «${name()}»"
        val hasKey = nyvexPrefs().getString("api_key", "").orEmpty().isNotBlank()
        val overlayOk = Settings.canDrawOverlays(this)
        info.text = "Спец. возможности: ${if (NyvexAccessibility.instance != null) "ON" else "OFF"}\n" +
            "Всплывающие окна: ${if (overlayOk) "ON" else "OFF"}\n" +
            "API-ключ: ${if (hasKey) "сохранён" else "нет"}\n" +
            "Голос: ${if (VoiceService.running) "ON" else "OFF"}\n" +
            "MCP: ${if (McpService.running) "ON" else "OFF"}  127.0.0.1:$PORT/mcp/${nyvexToken()}"
    }
}
