package app.nyvex.mcp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.widget.Button
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.WindowManager
import android.content.res.Configuration
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.Typeface
import android.app.AlertDialog
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.security.SecureRandom
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

const val PORT = 8765

fun Context.nyvexPrefs(): SharedPreferences = getSharedPreferences("nyvex", Context.MODE_PRIVATE)

fun Context.nyvexToken(): String =
    nyvexPrefs().getString("token", null) ?: newToken(nyvexPrefs())

fun newToken(p: SharedPreferences): String {
    val b = ByteArray(24)
    SecureRandom().nextBytes(b)
    val t = Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    p.edit().putString("token", t).apply()
    return t
}

// ───────────────────────── Accessibility: руки и глаза ─────────────────────────
class NyvexAccessibility : AccessibilityService() {
    companion object {
        @Volatile var instance: NyvexAccessibility? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun gesture(path: Path, dur: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur.coerceAtLeast(1))).build()
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(10, TimeUnit.SECONDS)
        return ok
    }

    fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 50)
    fun longPress(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 800)
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) =
        gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, ms)

    fun key(name: String): Boolean {
        val a = when (name.uppercase()) {
            "BACK" -> GLOBAL_ACTION_BACK
            "HOME" -> GLOBAL_ACTION_HOME
            "RECENTS", "APP_SWITCH" -> GLOBAL_ACTION_RECENTS
            "NOTIFICATIONS" -> GLOBAL_ACTION_NOTIFICATIONS
            "QUICK_SETTINGS" -> GLOBAL_ACTION_QUICK_SETTINGS
            "LOCK" -> GLOBAL_ACTION_LOCK_SCREEN
            "POWER" -> GLOBAL_ACTION_POWER_DIALOG
            else -> return false
        }
        return performGlobalAction(a)
    }

    fun typeText(text: String, replace: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val old = if (replace) "" else node.text?.toString().orEmpty()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findEditable(c)?.let { return it } }
        return null
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var n: AccessibilityNodeInfo = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return false
        val r = Rect(); n.getBoundsInScreen(r)
        while (!n.isClickable) n = n.parent ?: return tap(r.centerX().toFloat(), r.centerY().toFloat())
        return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun uiTree(): String {
        val root = rootInActiveWindow ?: return "нет активного окна"
        val sb = StringBuilder()
        dump(root, sb, 0)
        return sb.toString()
    }

    private fun dump(n: AccessibilityNodeInfo, sb: StringBuilder, d: Int) {
        val r = Rect(); n.getBoundsInScreen(r)
        val t = n.text?.toString().orEmpty()
        val c = n.contentDescription?.toString().orEmpty()
        if (t.isNotEmpty() || c.isNotEmpty() || n.isClickable || n.isEditable) {
            sb.append(" ".repeat(minOf(d, 10)))
                .append(n.className?.toString()?.substringAfterLast('.'))
                .append(" @").append(r.centerX()).append(',').append(r.centerY())
            if (t.isNotEmpty()) sb.append(" text=\"").append(t.take(120)).append('"')
            if (c.isNotEmpty()) sb.append(" desc=\"").append(c.take(120)).append('"')
            n.viewIdResourceName?.let { sb.append(" id=").append(it.substringAfter(":id/")) }
            if (n.isClickable) sb.append(" [click]")
            if (n.isEditable) sb.append(" [edit]")
            sb.append('\n')
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { dump(it, sb, d + 1) }
    }

    /** JPEG в base64 или null (нужен Android 11+). */
    fun screenshot(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: String? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bmp != null) {
                    val s = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 55, s)
                    out = Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP)
                }
                latch.countDown()
            }
            override fun onFailure(code: Int) { latch.countDown() }
        })
        latch.await(10, TimeUnit.SECONDS)
        return out
    }

    fun screenSize(): String {
        val m = resources.displayMetrics
        return "${m.widthPixels}x${m.heightPixels}"
    }
}

// ───────────────────────── MCP-сервер (Streamable HTTP, JSON-RPC) ─────────────────────────
class McpServer(private val ctx: Context, private val token: () -> String) :
    NanoHTTPD("127.0.0.1", PORT) {

    private fun txt(s: String) = JSONObject().put("content", JSONArray().put(JSONObject().put("type", "text").put("text", s)))
    private fun err(s: String) = txt(s).put("isError", true)

    private fun tool(name: String, desc: String, props: List<Pair<String, String>> = emptyList(), req: List<String> = props.map { it.first }): JSONObject {
        val p = JSONObject()
        props.forEach { p.put(it.first, JSONObject().put("type", it.second)) }
        return JSONObject().put("name", name).put("description", desc).put(
            "inputSchema", JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(req))
        )
    }

    fun tools() = JSONArray()
        .put(tool("screenshot", "Скриншот экрана (JPEG)"))
        .put(tool("ui_tree", "Дерево элементов экрана: текст, центр @x,y, [click]/[edit]. Точнее скриншота для кликов"))
        .put(tool("screen_size", "Разрешение экрана в пикселях"))
        .put(tool("tap", "Тап по координатам", listOf("x" to "number", "y" to "number")))
        .put(tool("long_press", "Долгое нажатие", listOf("x" to "number", "y" to "number")))
        .put(tool("swipe", "Свайп/скролл", listOf("x1" to "number", "y1" to "number", "x2" to "number", "y2" to "number", "duration_ms" to "number"), listOf("x1", "y1", "x2", "y2")))
        .put(tool("type_text", "Ввод текста в активное поле (любые языки). replace=true заменяет текст", listOf("text" to "string", "replace" to "boolean"), listOf("text")))
        .put(tool("click_text", "Нажать элемент по тексту", listOf("text" to "string")))
        .put(tool("key", "BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK, POWER", listOf("name" to "string")))
        .put(tool("list_apps", "Установленные приложения: название | пакет"))
        .put(tool("open_app", "Запустить приложение по пакету", listOf("package" to "string")))
        .put(tool("open_url", "Открыть ссылку", listOf("url" to "string")))
        .put(tool("wait", "Пауза в мс (макс 10000)", listOf("ms" to "number")))

    fun call(name: String, a: JSONObject): JSONObject {
        val svc = NyvexAccessibility.instance
        val c: Context = svc ?: ctx
        try {
            when (name) {
                "list_apps" -> {
                    val pm = c.packageManager
                    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    return txt(pm.queryIntentActivities(i, 0).joinToString("\n") { "${it.loadLabel(pm)} | ${it.activityInfo.packageName}" })
                }
                "open_app" -> {
                    val i = c.packageManager.getLaunchIntentForPackage(a.getString("package")) ?: return err("пакет не найден")
                    c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return txt("ok")
                }
                "open_url" -> {
                    c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return txt("ok")
                }
                "wait" -> { Thread.sleep(a.optLong("ms", 1000).coerceIn(0, 10000)); return txt("ok") }
            }
            if (svc == null) return err("Спец. возможности NyvexMCP выключены. Включи их в настройках телефона.")
            fun f(k: String) = a.getDouble(k).toFloat()
            return when (name) {
                "screenshot" -> {
                    val b64 = svc.screenshot() ?: return err("скриншот недоступен (нужен Android 11+)")
                    JSONObject().put("content", JSONArray().put(JSONObject().put("type", "image").put("data", b64).put("mimeType", "image/jpeg")))
                }
                "ui_tree" -> txt(svc.uiTree())
                "screen_size" -> txt(svc.screenSize())
                "tap" -> txt(if (svc.tap(f("x"), f("y"))) "ok" else "fail")
                "long_press" -> txt(if (svc.longPress(f("x"), f("y"))) "ok" else "fail")
                "swipe" -> txt(if (svc.swipe(f("x1"), f("y1"), f("x2"), f("y2"), a.optLong("duration_ms", 300))) "ok" else "fail")
                "type_text" -> txt(if (svc.typeText(a.getString("text"), a.optBoolean("replace", false))) "ok" else "нет поля ввода в фокусе")
                "click_text" -> txt(if (svc.clickText(a.getString("text"))) "ok" else "не найдено")
                "key" -> txt(if (svc.key(a.getString("name"))) "ok" else "fail")
                else -> err("неизвестный инструмент")
            }
        } catch (e: Exception) {
            return err(e.message ?: e.toString())
        }
    }

    private fun plain(s: Status, t: String) = newFixedLengthResponse(s, "text/plain", t)

    override fun serve(s: IHTTPSession): Response {
        val tok = token()
        val viaPath = MessageDigest.isEqual(s.uri.toByteArray(), "/mcp/$tok".toByteArray())
        val viaHeader = s.uri == "/mcp" &&
            MessageDigest.isEqual((s.headers["authorization"] ?: "").toByteArray(), "Bearer $tok".toByteArray())
        if (!viaPath && !viaHeader) return plain(Status.UNAUTHORIZED, "unauthorized")
        if (s.method == Method.DELETE) return plain(Status.OK, "")
        if (s.method != Method.POST) return plain(Status.METHOD_NOT_ALLOWED, "")
        return try {
            val files = HashMap<String, String>()
            s.parseBody(files)
            val req = JSONObject(files["postData"] ?: "{}")
            val id = req.opt("id") ?: return plain(Status.ACCEPTED, "")
            val params = req.optJSONObject("params") ?: JSONObject()
            val res = JSONObject().put("jsonrpc", "2.0").put("id", id)
            when (req.optString("method")) {
                "initialize" -> res.put("result", JSONObject()
                    .put("protocolVersion", params.optString("protocolVersion", "2025-03-26"))
                    .put("capabilities", JSONObject().put("tools", JSONObject()))
                    .put("serverInfo", JSONObject().put("name", "NyvexMCP").put("version", "1.8")))
                "ping" -> res.put("result", JSONObject())
                "tools/list" -> res.put("result", JSONObject().put("tools", tools()))
                "tools/call" -> res.put("result", call(params.optString("name"), params.optJSONObject("arguments") ?: JSONObject()))
                else -> res.put("error", JSONObject().put("code", -32601).put("message", "method not found"))
            }
            newFixedLengthResponse(Status.OK, "application/json", res.toString())
        } catch (e: Exception) {
            plain(Status.BAD_REQUEST, e.message ?: "bad request")
        }
    }
}

// ───────────────────────── Фоновая служба (вкл/выкл) ─────────────────────────
class McpService : Service() {
    companion object {
        @Volatile var running = false
        const val STOP = "app.nyvex.mcp.STOP"
    }

    private var server: McpServer? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?) = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("mcp", "NyvexMCP", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, McpService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "mcp")
            .setContentTitle("NyvexMCP включён")
            .setContentText("127.0.0.1:$PORT")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (server == null) {
            server = McpServer(this) { nyvexToken() }.also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
            wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nyvex:mcp").apply { acquire() }
        }
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop(); server = null
        wl?.let { if (it.isHeld) it.release() }
        running = false
        super.onDestroy()
    }
}

// ───────────────────────── Агент: голос → Claude API → действия на телефоне ─────────────────────────
fun Context.isDarkTheme(): Boolean = when (nyvexPrefs().getString("theme", "system")) {
    "dark" -> true
    "light" -> false
    else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
}

fun Context.themeRes(): Int =
    if (isDarkTheme()) android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar

fun Context.assistantName(): String = nyvexPrefs().getString("name", "").orEmpty().ifBlank { "Клод" }

data class Model(val id: String, val title: String)

object Models {
    val defaults = listOf(
        Model("claude-haiku-5-5", "Claude Haiku 5.5"),
        Model("claude-sonnet-5-5", "Claude Sonnet 5.5"),
        Model("claude-opus-5-5", "Claude Opus 5.5"),
        Model("claude-fable-5-2", "Claude Fable 5.2"),
        Model("gpt-6-luna", "GPT-6 Luna"),
        Model("gpt-6.2-sol", "GPT-6.2 Sol"),
        Model("gpt-6.2-astra", "GPT-6.2 Astra"),
        Model("gpt-6.1-terra", "GPT-6.1 Terra"),
        Model("deepseek-v4-pro", "DeepSeek V4 Pro"),
        Model("deepseek-v4.1-flash-1017", "DeepSeek V4.1 Flash 1017"),
        Model("gemini-4-argon", "Gemini 4 Argon"),
        Model("gemini-3.8-flash", "Gemini 3.8 Flash"),
        Model("glm-5.3", "GLM 5.3"),
        Model("glm-5.3-flash", "GLM 5.3 Flash"),
        Model("kimi-k3.1-pro", "Kimi K3.1 Pro")
    )

    var list: List<Model> = defaults

    fun title(id: String): String = defaults.find { it.id == id }?.title ?: id

    fun load(ctx: Context) {
        val s = ctx.nyvexPrefs().getString("models", null) ?: return
        list = s.split("\n").filter { it.isNotBlank() }.map { Model(it, title(it)) }
    }

    /** Список моделей с сервиса (GET /models). Вызывать из фонового потока. */
    fun fetch(ctx: Context): List<Model> {
        val p = ctx.nyvexPrefs()
        val base = p.getString("base_url", "").orEmpty().ifBlank { "https://darkapi.shop/v1" }.trimEnd('/')
        val c = URL("$base/models").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Authorization", "Bearer " + p.getString("api_key", "").orEmpty())
        val txt = c.inputStream.bufferedReader().use { it.readText() }
        val arr = JSONObject(txt).getJSONArray("data")
        val res = (0 until arr.length()).map {
            val id = arr.getJSONObject(it).getString("id")
            Model(id, title(id))
        }
        p.edit().putString("models", res.joinToString("\n") { it.id }).apply()
        list = res
        return res
    }

    fun vendor(id: String): String = when {
        id.startsWith("claude") -> "Anthropic"
        id.startsWith("gpt") -> "OpenAI"
        id.startsWith("deepseek") -> "DeepSeek"
        id.startsWith("gemini") -> "Google"
        id.startsWith("glm") -> "Zhipu AI"
        id.startsWith("kimi") -> "Moonshot AI"
        else -> "Модель"
    }

    /** символ + два цвета градиента */
    fun brand(id: String): Triple<String, Int, Int> = when {
        id.startsWith("claude") -> Triple("✻", 0xFFE8895F.toInt(), 0xFFCC5F37.toInt())
        id.startsWith("gpt") -> Triple("O", 0xFF2FBF9B.toInt(), 0xFF0E8A6D.toInt())
        id.startsWith("deepseek") -> Triple("D", 0xFF5B7CFF.toInt(), 0xFF3350E0.toInt())
        id.startsWith("gemini") -> Triple("G", 0xFF4F8CFF.toInt(), 0xFF9B6BFF.toInt())
        id.startsWith("glm") -> Triple("Z", 0xFF3B5BFF.toInt(), 0xFF2236B8.toInt())
        id.startsWith("kimi") -> Triple("K", 0xFF3A3F4B.toInt(), 0xFF14161A.toInt())
        else -> Triple("?", 0xFF9AA0AA.toInt(), 0xFF6B7280.toInt())
    }

    fun company(id: String): Pair<String, Int> = when {
        id.startsWith("claude") -> "C" to 0xFFD97757.toInt()
        id.startsWith("gpt") -> "O" to 0xFF10A37F.toInt()
        id.startsWith("deepseek") -> "D" to 0xFF4D6BFE.toInt()
        id.startsWith("gemini") -> "G" to 0xFF4285F4.toInt()
        id.startsWith("glm") -> "Z" to 0xFF3859FF.toInt()
        id.startsWith("kimi") -> "K" to 0xFF222222.toInt()
        else -> "?" to 0xFF888888.toInt()
    }
}

// ───────────────────────── Дизайн ─────────────────────────
const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class Pal(val dark: Boolean) {
    val bg = if (dark) 0xFF0F1115.toInt() else 0xFFF4F5FA.toInt()
    val card = if (dark) 0xFF1A1D24.toInt() else 0xFFFFFFFF.toInt()
    val ai = if (dark) 0xFF1F232B.toInt() else 0xFFFFFFFF.toInt()
    val text = if (dark) 0xFFF2F3F5.toInt() else 0xFF14161A.toInt()
    val sub = if (dark) 0xFF9AA0AA.toInt() else 0xFF6B7280.toInt()
    val line = if (dark) 0xFF2A2E37.toInt() else 0xFFE4E6EC.toInt()
    val a1 = 0xFF7C5CFF.toInt()
    val a2 = 0xFF4F8CFF.toInt()
}

fun Context.pal() = Pal(isDarkTheme())
fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.shape(color: Int, r: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
    setColor(color)
    cornerRadius = dp(r).toFloat()
    if (stroke != 0) setStroke(dp(1), stroke)
}

fun Context.gradient(r: Int): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal().a1, pal().a2)).apply { cornerRadius = dp(r).toFloat() }

fun Context.gradientOval(): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal().a1, pal().a2)).apply { shape = GradientDrawable.OVAL }

fun Context.radii(tl: Int, tr: Int, br: Int, bl: Int): FloatArray =
    floatArrayOf(dp(tl).toFloat(), dp(tl).toFloat(), dp(tr).toFloat(), dp(tr).toFloat(),
        dp(br).toFloat(), dp(br).toFloat(), dp(bl).toFloat(), dp(bl).toFloat())

fun Context.ripple(d: Drawable): Drawable = RippleDrawable(ColorStateList.valueOf(0x33808080), d, null)

fun Activity.styleWindow() {
    val p = pal()
    window.statusBarColor = p.bg
    window.navigationBarColor = p.bg
    window.setBackgroundDrawable(ColorDrawable(p.bg))
    window.decorView.systemUiVisibility =
        if (p.dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
}

fun Context.label(t: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
    text = t
    textSize = size
    setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
}

fun Context.pill(t: String, primary: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
    text = t
    gravity = Gravity.CENTER
    textSize = 15f
    typeface = Typeface.DEFAULT_BOLD
    setTextColor(if (primary) Color.WHITE else pal().text)
    setPadding(dp(18), dp(13), dp(18), dp(13))
    background = ripple(if (primary) gradient(14) else shape(pal().bg, 14, pal().line))
    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
    setOnClickListener { onClick() }
}

fun Context.iconBtn(sym: String, onClick: () -> Unit): TextView = TextView(this).apply {
    text = sym
    textSize = 20f
    gravity = Gravity.CENTER
    setTextColor(pal().text)
    background = ripple(shape(pal().card, 20, pal().line))
    layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(6) }
    setOnClickListener { onClick() }
}

fun Context.card(title: String?): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(16), dp(14), dp(16), dp(16))
    background = shape(pal().card, 18, pal().line)
    elevation = dp(2).toFloat()
    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
    if (title != null) addView(label(title.uppercase(), 12f, pal().sub, true))
}

fun Context.inputField(h: String, v: String, type: Int): EditText = EditText(this).apply {
    hint = h
    setHintTextColor(pal().sub)
    setTextColor(pal().text)
    setText(v)
    inputType = type
    textSize = 15f
    setPadding(dp(14), dp(12), dp(14), dp(12))
    background = shape(pal().bg, 12, pal().line)
    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
}

fun Context.avatar(letter: String, sizeDp: Int): TextView = TextView(this).apply {
    text = letter
    gravity = Gravity.CENTER
    setTextColor(Color.WHITE)
    typeface = Typeface.DEFAULT_BOLD
    textSize = sizeDp / 2.4f
    background = gradientOval()
    layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
}

/** Иконка компании: градиентный кружок с символом. */
fun Context.badge(id: String, sizeDp: Int): TextView {
    val (sym, c1, c2) = Models.brand(id)
    return TextView(this).apply {
        text = sym
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        textSize = sizeDp / 2.4f
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply { shape = GradientDrawable.OVAL }
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }
}

fun Activity.pickModel(onPick: (Model) -> Unit) {
    val p = pal()
    val cur = nyvexPrefs().getString("model", "").orEmpty()
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(14)) }
    col.addView(label("Выбери модель", 20f, p.text, true).apply { setPadding(dp(8), dp(12), dp(8), dp(10)) })
    var dlg: AlertDialog? = null
    val tint = if (p.dark) 0x337C5CFF else 0x1A7C5CFF
    for (m in Models.list) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = ripple(shape(if (m.id == cur) tint else Color.TRANSPARENT, 14))
        }
        row.addView(badge(m.id, 40))
        val tx = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        tx.addView(label(m.title, 16f, p.text, true))
        tx.addView(label(Models.vendor(m.id), 12f, p.sub))
        row.addView(tx)
        if (m.id == cur) row.addView(label("✓", 20f, p.a1, true))
        row.setOnClickListener { dlg?.dismiss(); onPick(m) }
        col.addView(row)
    }
    val d = AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(col) }).create()
    d.window?.setBackgroundDrawable(shape(p.card, 24))
    dlg = d
    d.show()
}

// ───────────────────────── Агент: голос/чат → API → действия на телефоне ─────────────────────────
object Agent {
    private class Cfg(val base: String, val key: String, val model: String) {
        val openai: Boolean get() = !model.startsWith("claude")
    }

    private var history = JSONArray()
    private var last = 0L
    private var lastOpenai: Boolean? = null
    private var sysPrompt = ""

    fun reset() { history = JSONArray() }

    private fun prompt(name: String, chat: Boolean) =
        "Ты $name, помощник на телефоне пользователя. Если нужно что-то сделать на экране, используй инструменты: " +
        "сначала ui_tree или screenshot, затем действия, затем проверь результат. Отвечай по-русски и коротко." +
        (if (chat) "" else " Ответ озвучивается: без markdown и списков.") +
        " Перед необратимыми действиями (платежи, удаление, отправка сообщений другим людям) спроси подтверждение."

    private fun cfg(ctx: Context): Cfg {
        val p = ctx.nyvexPrefs()
        return Cfg(
            p.getString("base_url", "").orEmpty().ifBlank { "https://darkapi.shop/v1" },
            p.getString("api_key", "").orEmpty(),
            p.getString("model", "").orEmpty()
        )
    }

    private fun endpoint(c: Cfg): String {
        val b = c.base.trim().trimEnd('/')
        if (b.endsWith("/messages") || b.endsWith("/chat/completions")) return b
        val v1 = if (b.endsWith("/v1")) b else "$b/v1"
        return v1 + if (c.openai) "/chat/completions" else "/messages"
    }

    fun run(ctx: Context, userText: String, chat: Boolean = false): String {
        val c = cfg(ctx)
        if (c.key.isBlank() || c.model.isBlank()) return "Зайдите в настройки и настройте модель и токен."
        sysPrompt = prompt(ctx.assistantName(), chat)
        if (!chat && System.currentTimeMillis() - last > 120_000) history = JSONArray()
        if (lastOpenai != null && lastOpenai != c.openai) history = JSONArray()
        lastOpenai = c.openai
        val srv = McpServer(ctx) { "" }
        val defs = srv.tools()
        val reply = if (c.openai) runOpenAI(c, srv, defs, userText) else runAnthropic(c, srv, defs, userText)
        last = System.currentTimeMillis()
        return reply
    }

    // формат Anthropic (/v1/messages) — для моделей Claude
    private fun runAnthropic(c: Cfg, srv: McpServer, defs: JSONArray, userText: String): String {
        val tools = JSONArray()
        for (i in 0 until defs.length()) {
            val t = defs.getJSONObject(i)
            tools.put(JSONObject().put("name", t.getString("name")).put("description", t.getString("description"))
                .put("input_schema", t.getJSONObject("inputSchema")))
        }
        history.put(JSONObject().put("role", "user").put("content", userText))
        for (step in 0 until 25) {
            pruneImages()
            val body = JSONObject().put("model", c.model).put("max_tokens", 1024).put("system", sysPrompt)
                .put("tools", tools).put("messages", history).toString()
            val resp = http(endpoint(c), mapOf("x-api-key" to c.key, "Authorization" to "Bearer ${c.key}", "anthropic-version" to "2023-06-01"), body)
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            if (resp.optString("stop_reason") != "tool_use") {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().ifBlank { "Готово" }
            }
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") != "tool_use") continue
                val r = srv.call(b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                val out = JSONArray()
                val rc = r.getJSONArray("content")
                for (j in 0 until rc.length()) {
                    val x = rc.getJSONObject(j)
                    if (x.getString("type") == "image") out.put(JSONObject().put("type", "image").put("source",
                        JSONObject().put("type", "base64").put("media_type", x.getString("mimeType")).put("data", x.getString("data"))))
                    else out.put(JSONObject().put("type", "text").put("text", x.getString("text")))
                }
                results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id"))
                    .put("content", out).put("is_error", r.optBoolean("isError", false)))
            }
            history.put(JSONObject().put("role", "user").put("content", results))
        }
        return "Не успел закончить, слишком много шагов."
    }

    // формат OpenAI (/v1/chat/completions) — для остальных моделей
    private fun runOpenAI(c: Cfg, srv: McpServer, defs: JSONArray, userText: String): String {
        val tools = JSONArray()
        for (i in 0 until defs.length()) {
            val t = defs.getJSONObject(i)
            tools.put(JSONObject().put("type", "function").put("function", JSONObject()
                .put("name", t.getString("name")).put("description", t.getString("description"))
                .put("parameters", t.getJSONObject("inputSchema"))))
        }
        history.put(JSONObject().put("role", "user").put("content", userText))
        for (step in 0 until 25) {
            pruneImagesOA()
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sysPrompt))
            for (i in 0 until history.length()) msgs.put(history.get(i))
            val body = JSONObject().put("model", c.model).put("max_tokens", 1024)
                .put("messages", msgs).put("tools", tools).toString()
            val resp = http(endpoint(c), mapOf("Authorization" to "Bearer ${c.key}"), body)
            val msg = resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
            history.put(msg)
            val calls = msg.optJSONArray("tool_calls")
            if (calls == null || calls.length() == 0) {
                val t = msg.optString("content")
                return if (t.isBlank() || t == "null") "Готово" else t
            }
            val imgs = ArrayList<String>()
            for (i in 0 until calls.length()) {
                val call = calls.getJSONObject(i)
                val fn = call.getJSONObject("function")
                val args = try { JSONObject(fn.optString("arguments", "{}").ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
                val r = srv.call(fn.getString("name"), args)
                val rc = r.getJSONArray("content")
                val sb = StringBuilder()
                for (j in 0 until rc.length()) {
                    val x = rc.getJSONObject(j)
                    if (x.getString("type") == "image") imgs.add(x.getString("data")) else sb.append(x.getString("text"))
                }
                if (sb.isEmpty()) sb.append("скриншот в следующем сообщении")
                history.put(JSONObject().put("role", "tool").put("tool_call_id", call.getString("id")).put("content", sb.toString()))
            }
            if (imgs.isNotEmpty()) {
                val parts = JSONArray().put(JSONObject().put("type", "text").put("text", "Скриншот экрана"))
                imgs.forEach { parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$it"))) }
                history.put(JSONObject().put("role", "user").put("content", parts))
            }
        }
        return "Не успел закончить, слишком много шагов."
    }

    private fun pruneImagesOA() {
        for (m in 0 until history.length() - 1) {
            val c = history.getJSONObject(m).opt("content") as? JSONArray ?: continue
            for (i in 0 until c.length()) {
                if (c.getJSONObject(i).optString("type") == "image_url")
                    c.put(i, JSONObject().put("type", "text").put("text", "[старый скриншот]"))
            }
        }
    }

    private fun pruneImages() {
        for (m in 0 until history.length() - 1) {
            val c = history.getJSONObject(m).opt("content") as? JSONArray ?: continue
            for (i in 0 until c.length()) {
                val b = c.getJSONObject(i)
                if (b.optString("type") != "tool_result") continue
                val inner = b.optJSONArray("content") ?: continue
                for (j in 0 until inner.length()) {
                    if (inner.getJSONObject(j).optString("type") == "image")
                        inner.put(j, JSONObject().put("type", "text").put("text", "[старый скриншот]"))
                }
            }
        }
    }

    private fun http(url: String, headers: Map<String, String>, body: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 90000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val st = if (code in 200..299) c.inputStream else c.errorStream
        val txt = st?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw RuntimeException("API $code: ${txt.take(200)}")
        return JSONObject(txt)
    }
}


// ───────────────────────── Голосовая служба ─────────────────────────
class VoiceService : Service() {
    companion object {
        @Volatile var running = false
        const val STOP = "app.nyvex.mcp.VSTOP"
    }

    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wl: PowerManager.WakeLock? = null
    private var busy = false
    private var awaiting = false
    private var overlay: TextView? = null
    private val hideOverlay = Runnable { removeOverlay() }

    private fun name() = nyvexPrefs().getString("name", "").orEmpty().ifBlank { "Клод" }

    private fun wakeRegex(): Regex {
        val alts = mutableListOf(Regex.escape(name().lowercase()))
        if (name() == "Клод") alts += listOf("клауд", "клот", "claude")
        return Regex(alts.joinToString("|"), RegexOption.IGNORE_CASE)
    }

    override fun onBind(i: Intent?) = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("voice", "Голосовой помощник", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, VoiceService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "voice")
            .setContentTitle("Слушаю: скажи «${name()}»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(2, n)
        if (!running) {
            running = true
            wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nyvex:voice").apply { acquire() }
            tts = TextToSpeech(this) { st ->
                val e = tts
                if (st == TextToSpeech.SUCCESS && e != null) {
                    e.language = Locale("ru", "RU")
                    e.setSpeechRate(1.05f)
                    e.setPitch(1.05f)
                    e.voices?.filter { it.locale.language == "ru" }?.maxByOrNull { it.quality }?.let { e.voice = it }
                    e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { main.post { busy = false; listen() } }
                        @Deprecated("deprecated") override fun onError(id: String?) { main.post { busy = false; listen() } }
                    })
                }
            }
            main.post {
                sr = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
                listen()
            }
        }
        return START_STICKY
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onError(e: Int) { main.postDelayed({ listen() }, 400) }
        override fun onResults(r: Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            handle(t)
        }
    }

    private fun listen() {
        if (!running || busy) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        try { sr?.startListening(i) } catch (e: Exception) { main.postDelayed({ listen() }, 1000) }
    }

    private fun handle(text: String) {
        val m = wakeRegex().find(text)
        val cmd = when {
            m != null -> text.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?')
            awaiting -> text.trim()
            else -> { listen(); return }
        }
        if (m != null) showOverlay("🎙 ${name()} слушает")
        if (cmd.isBlank()) { awaiting = true; say("Слушаю"); return }
        awaiting = false
        busy = true
        showOverlay("… ${name()} думает")
        Thread {
            val reply = try { Agent.run(this, cmd) } catch (e: Exception) { "Ошибка: ${e.message}" }
            awaiting = reply.trimEnd().endsWith("?")
            main.post { say(reply) }
        }.start()
    }

    private fun say(t: String) {
        showOverlay(t)
        val engine = tts
        if (!nyvexPrefs().getBoolean("speak", true) || engine == null) {
            busy = false
            main.postDelayed({ listen() }, 300)
            return
        }
        busy = true
        engine.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun createOverlay(wm: WindowManager): TextView {
        val tv = TextView(this).apply {
            setPadding(48, 28, 48, 28)
            textSize = 17f
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xEE7C5CFF.toInt(), 0xEE4F8CFF.toInt())).apply { cornerRadius = 72f }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 180 }
        wm.addView(tv, lp)
        return tv
    }

    private fun showOverlay(t: String) {
        main.post {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
                return@post
            }
            val view = overlay ?: createOverlay(getSystemService(WindowManager::class.java)).also { overlay = it }
            view.text = t
            main.removeCallbacks(hideOverlay)
            main.postDelayed(hideOverlay, 5000)
        }
    }

    private fun removeOverlay() {
        overlay?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        overlay = null
    }

    override fun onDestroy() {
        running = false
        removeOverlay()
        sr?.destroy(); sr = null
        tts?.shutdown(); tts = null
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}

// ───────────────────────── Настройки ─────────────────────────
class SettingsActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var swVoice: Switch
    private lateinit var swMcp: Switch
    private lateinit var swSpeak: Switch
    private lateinit var nameField: EditText
    private lateinit var urlField: EditText
    private lateinit var keyField: EditText
    private lateinit var modelRow: LinearLayout
    private val chips = mutableListOf<TextView>()
    private var themeKey = "system"
    private var updating = false
    private val h = Handler(Looper.getMainLooper())
    private val themes = listOf("system" to "Системная", "light" to "Светлая", "dark" to "Тёмная")

    override fun onCreate(b: Bundle?) {
        setTheme(themeRes())
        super.onCreate(b)
        styleWindow()
        Models.load(this)
        val p = pal()
        val prefs = nyvexPrefs()
        themeKey = prefs.getString("theme", "system") ?: "system"

        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(16), dp(6))
        }
        head.addView(iconBtn("‹") { finish() })
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        ht.addView(label("Настройки", 22f, p.text, true))
        ht.addView(label("Версия " + packageManager.getPackageInfo(packageName, 0).versionName, 13f, p.sub))
        head.addView(ht)
        outer.addView(head)

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(16)) }

        // Статус
        val cStatus = card("Статус")
        swVoice = Switch(this).apply { textSize = 16f; setTextColor(p.text); setPadding(0, dp(10), 0, dp(6)) }
        swVoice.setOnCheckedChangeListener { _, on -> toggle(VoiceService::class.java, on) }
        swMcp = Switch(this).apply { text = "MCP-сервер (для внешнего Claude)"; textSize = 16f; setTextColor(p.text); setPadding(0, dp(6), 0, dp(10)) }
        swMcp.setOnCheckedChangeListener { _, on -> toggle(McpService::class.java, on) }
        info = label("", 13f, p.sub).apply { setTextIsSelectable(true) }
        cStatus.addView(swVoice); cStatus.addView(swMcp); cStatus.addView(info)
        col.addView(cStatus)

        // Ассистент
        val cAs = card("Ассистент")
        nameField = inputField("Имя ассистента (пусто = Клод)", prefs.getString("name", "").orEmpty(), InputType.TYPE_CLASS_TEXT)
        swSpeak = Switch(this).apply { text = "Отвечать голосом"; textSize = 16f; setTextColor(p.text); isChecked = prefs.getBoolean("speak", true); setPadding(0, dp(14), 0, 0) }
        cAs.addView(nameField); cAs.addView(swSpeak)
        col.addView(cAs)

        // Тема
        val cTheme = card("Тема")
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        themes.forEach { (key, nm) ->
            val c = TextView(this).apply { text = nm; gravity = Gravity.CENTER; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(11), 0, dp(11)) }
            c.setOnClickListener { themeKey = key; styleChips() }
            chips.add(c)
            chipRow.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        }
        styleChips()
        cTheme.addView(chipRow)
        col.addView(cTheme)

        // Модель и сервис
        val cModel = card("Модель и сервис")
        modelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = ripple(shape(p.bg, 14, p.line))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
        }
        modelRow.setOnClickListener { pickModel { m -> nyvexPrefs().edit().putString("model", m.id).apply(); refresh() } }
        urlField = inputField("Base URL (пусто = https://darkapi.shop/v1)", prefs.getString("base_url", "").orEmpty(),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        keyField = inputField("API-ключ (вставь, чтобы заменить)", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        cModel.addView(modelRow); cModel.addView(urlField); cModel.addView(keyField)
        cModel.addView(pill("Загрузить список моделей с сервиса", false) { loadModels() })
        col.addView(cModel)

        // Система
        val cSys = card("Система")
        cSys.addView(pill("Разрешить всплывающие окна", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        cSys.addView(pill("Включить спец. возможности", false) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        cSys.addView(pill("Отключить оптимизацию батареи", false) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        cSys.addView(pill("Копировать MCP-URL (подставь свой туннель)", false) {
            val url = "https://ТВОЙ-ТУННЕЛЬ/mcp/${nyvexToken()}"
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("mcp", url))
            Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
        })
        cSys.addView(pill("Сменить MCP-токен", false) { newToken(nyvexPrefs()); refresh() })
        col.addView(cSys)

        outer.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val bar = LinearLayout(this).apply { setPadding(dp(16), dp(6), dp(16), dp(12)); setBackgroundColor(p.bg) }
        bar.addView(pill("Сохранить", true) { save() })
        outer.addView(bar)
        setContentView(outer)
        refresh()
    }

    private fun styleChips() {
        val p = pal()
        chips.forEachIndexed { i, c ->
            val sel = themes[i].first == themeKey
            c.background = if (sel) gradient(12) else shape(p.bg, 12, p.line)
            c.setTextColor(if (sel) Color.WHITE else p.text)
        }
    }

    private fun toggle(cls: Class<*>, on: Boolean) {
        if (updating) return
        val i = Intent(this, cls)
        if (on) startForegroundService(i) else stopService(i)
        h.postDelayed({ refresh() }, 700)
    }

    private fun save() {
        val prefs = nyvexPrefs()
        val prevTheme = prefs.getString("theme", "system")
        val e = prefs.edit()
            .putString("name", nameField.text.toString().trim())
            .putBoolean("speak", swSpeak.isChecked)
            .putString("theme", themeKey)
            .putString("base_url", urlField.text.toString().trim())
        val k = keyField.text.toString().trim()
        if (k.isNotEmpty()) e.putString("api_key", k)
        e.apply()
        keyField.setText("")
        Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        if (themeKey != prevTheme) recreate() else refresh()
    }

    private fun loadModels() {
        Toast.makeText(this, "Загружаю список…", Toast.LENGTH_SHORT).show()
        Thread {
            val res = try { Models.fetch(this) } catch (e: Exception) { null }
            runOnUiThread {
                if (res.isNullOrEmpty()) Toast.makeText(this, "Не загрузилось. Проверь ключ и адрес", Toast.LENGTH_LONG).show()
                else Toast.makeText(this, "Моделей: ${res.size}", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val p = pal()
        updating = true
        swVoice.isChecked = VoiceService.running
        swMcp.isChecked = McpService.running
        updating = false
        swVoice.text = "Голос: скажи «${assistantName()}»"
        val pr = nyvexPrefs()
        val mid = pr.getString("model", "").orEmpty()
        modelRow.removeAllViews()
        if (mid.isBlank()) {
            modelRow.addView(label("Модель не выбрана. Нажми, чтобы выбрать", 15f, p.sub))
        } else {
            modelRow.addView(badge(mid, 36))
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
            t.addView(label(Models.title(mid), 16f, p.text, true))
            t.addView(label(Models.vendor(mid), 12f, p.sub))
            modelRow.addView(t)
            modelRow.addView(label("▾", 18f, p.sub))
        }
        info.text = "Спец. возможности: ${if (NyvexAccessibility.instance != null) "ON" else "OFF"}\n" +
            "Всплывающие окна: ${if (Settings.canDrawOverlays(this)) "ON" else "OFF"}\n" +
            "API-ключ: ${if (pr.getString("api_key", "").isNullOrBlank()) "нет" else "сохранён"}\n" +
            "MCP: ${if (McpService.running) "ON" else "OFF"}  127.0.0.1:$PORT/mcp/${nyvexToken()}"
    }
}

// ───────────────────────── Главный экран: чат ─────────────────────────
class MainActivity : Activity() {
    private lateinit var msgs: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var chip: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private var dark = false
    private var empty = true

    override fun onCreate(b: Bundle?) {
        dark = isDarkTheme()
        setTheme(themeRes())
        super.onCreate(b)
        styleWindow()
        Models.load(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS", "android.permission.RECORD_AUDIO"), 1)
        val p = pal()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(12), dp(10))
        }
        head.addView(avatar(assistantName().take(1).uppercase(), 42))
        val ht = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        titleView = label("", 18f, p.text, true)
        subtitleView = label("", 12f, p.sub)
        ht.addView(titleView); ht.addView(subtitleView)
        head.addView(ht)
        head.addView(iconBtn("+") { Agent.reset(); showEmpty() })
        head.addView(iconBtn("⚙") { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) })
        root.addView(head)

        msgs = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(4), dp(14), dp(14)) }
        scroll = ScrollView(this).apply { addView(msgs) }
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = shape(p.card, 28, p.line)
            elevation = dp(3).toFloat()
        }
        chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = ripple(shape(p.bg, 22))
        }
        chip.setOnClickListener { pickModel { m -> nyvexPrefs().edit().putString("model", m.id).apply(); refreshHeader() } }
        input = EditText(this).apply {
            hint = "Сообщение…"
            setHintTextColor(p.sub)
            setTextColor(p.text)
            background = null
            maxLines = 5
            setPadding(dp(10), dp(8), dp(10), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val sendBtn = TextView(this).apply {
            text = "➤"
            gravity = Gravity.CENTER
            textSize = 18f
            setTextColor(Color.WHITE)
            background = ripple(gradientOval())
            setOnClickListener { send() }
        }
        bar.addView(chip)
        bar.addView(input)
        bar.addView(sendBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        val wrap = LinearLayout(this).apply { setPadding(dp(12), dp(6), dp(12), dp(12)) }
        wrap.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(wrap)

        setContentView(root)
        showEmpty()
        refreshHeader()
    }

    override fun onResume() {
        super.onResume()
        if (dark != isDarkTheme()) { recreate(); return }
        refreshHeader()
        if (empty) showEmpty()
    }

    private fun refreshHeader() {
        val p = pal()
        val id = nyvexPrefs().getString("model", "").orEmpty()
        titleView.text = assistantName()
        subtitleView.text = if (id.isBlank()) "модель не выбрана" else Models.title(id) + " · " + Models.vendor(id)
        input.hint = "Напиши ${assistantName()}…"
        chip.removeAllViews()
        if (id.isBlank()) {
            chip.addView(label("Модель ▾", 14f, p.text, true))
        } else {
            chip.addView(badge(id, 26))
            chip.addView(label("▾", 14f, p.sub).apply { setPadding(dp(6), 0, dp(2), 0) })
        }
    }

    private fun showEmpty() {
        val p = pal()
        msgs.removeAllViews()
        empty = true
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(40), 0, 0)
        }
        box.addView(avatar(assistantName().take(1).uppercase(), 76))
        box.addView(label("Привет! Я ${assistantName()}", 24f, p.text, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(4)) })
        box.addView(label("Спроси что угодно или попроси что-то сделать на телефоне", 15f, p.sub).apply {
            gravity = Gravity.CENTER; setPadding(dp(24), 0, dp(24), dp(20))
        })
        listOf("Что сейчас на экране?", "Открой настройки", "Покажи установленные приложения").forEach { sug ->
            box.addView(pill(sug, false) { input.setText(sug); send() })
        }
        msgs.addView(box, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun scrollDown() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun userBubble(t: String) {
        val p = pal()
        val tv = TextView(this).apply {
            text = t
            textSize = 16f
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            maxWidth = (resources.displayMetrics.widthPixels * 0.8).toInt()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.a1, p.a2)).apply { cornerRadii = radii(18, 18, 4, 18) }
        }
        msgs.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP).apply { gravity = Gravity.END; topMargin = dp(10) })
        scrollDown()
    }

    private fun aiBubble(t: String): TextView {
        val p = pal()
        val id = nyvexPrefs().getString("model", "").orEmpty()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        val bd = badge(id, 28)
        (bd.layoutParams as LinearLayout.LayoutParams).marginEnd = dp(8)
        row.addView(bd)
        val tv = TextView(this).apply {
            text = t
            textSize = 16f
            setTextColor(p.text)
            setTextIsSelectable(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
            background = GradientDrawable().apply {
                setColor(p.ai)
                cornerRadii = radii(18, 18, 18, 4)
                setStroke(dp(1), p.line)
            }
        }
        row.addView(tv)
        msgs.addView(row, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(10) })
        scrollDown()
        return tv
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (empty) { msgs.removeAllViews(); empty = false }
        input.setText("")
        userBubble(text)
        val wait = aiBubble("● ● ●")
        Thread {
            val reply = try { Agent.run(this, text, chat = true) } catch (e: Exception) { "Ошибка: ${e.message}" }
            runOnUiThread { wait.text = reply; scrollDown() }
        }.start()
    }
}
