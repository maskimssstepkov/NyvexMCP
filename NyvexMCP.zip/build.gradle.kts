plugins {
    id("com.android.application") version "8.5.2"
    id("org.jetbrains.kotlin.android") version "1.9.24"
}
android {
    namespace = "app.nyvex.mcp"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.nyvex.mcp"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "1.8"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("org.nanohttpd:nanohttpd:2.3.1") }
