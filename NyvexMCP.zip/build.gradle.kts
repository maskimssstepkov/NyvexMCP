plugins {
    id("com.android.application") version "8.5.2"
    id("org.jetbrains.kotlin.android") version "1.9.24"
}
android {
    namespace = "app.nyvex.mcp"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.nyvex.mcp"
        minSdk = 26
        targetSdk = 34
        versionCode = 15
        versionName = "1.9"
    }
    signingConfigs {
        create("nyvex") {
            storeFile = file("keystore/nyvex.jks")
            storePassword = "nyvex123"
            keyAlias = "nyvex"
            keyPassword = "nyvex123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("nyvex") }
        getByName("release") { signingConfig = signingConfigs.getByName("nyvex") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("org.nanohttpd:nanohttpd:2.3.1") }
