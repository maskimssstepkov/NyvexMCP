# NyvexMCP

Android app with a local MCP endpoint, accessibility actions and optional voice assistant.

## Build locally

Requires JDK 17 and Gradle 8.7:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/`.

## Build with GitHub Actions

1. Create a GitHub repository and upload the project files (including `.github/workflows/android-build.yml`).
2. Push the code to `main` or `master`, or open **Actions → Android APK → Run workflow**.
3. Open the completed workflow run and download the `NyvexMCP-debug-apk` artifact.

The workflow builds a debug APK. For a public release, configure Android signing with GitHub Actions secrets and create a separate signed release workflow. Never commit API keys or signing passwords to the repository.

## Assistant identity

On first launch, the assistant chooses a display name from the built-in name list. You can change it in **Имя и оформление ассистента**, or ask it to choose another name. The activation phrase can be configured separately. The app title shown inside the interface and foreground notification is also configurable; the Android launcher label remains `NyvexMCP` until changed in the manifest and rebuilt.

## Notes

- Voice recognition quality and wake-phrase reliability depend on Android's installed speech recognition service and device restrictions.
- TTS voice tone depends on the voices installed on the device; rate and pitch are adjustable in the app.
- Keep the MCP endpoint bound to localhost. Do not expose it to the public internet without a separate authentication and transport-security review.
